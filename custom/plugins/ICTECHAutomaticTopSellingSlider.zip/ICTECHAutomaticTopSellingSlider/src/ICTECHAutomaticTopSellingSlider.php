<?php declare(strict_types=1);

namespace ICTECHAutomaticTopSellingSlider;

use Shopware\Core\Framework\Plugin;

class ICTECHAutomaticTopSellingSlider extends Plugin
{
}
